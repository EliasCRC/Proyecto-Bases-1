﻿namespace ProyectoBases
{
    partial class CrearReserv
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBox_telc = new System.Windows.Forms.TextBox();
            this.textBox_telref = new System.Windows.Forms.TextBox();
            this.pickerDate = new System.Windows.Forms.DateTimePicker();
            this.label_fecha = new System.Windows.Forms.Label();
            this.label_hora = new System.Windows.Forms.Label();
            this.label_telref = new System.Windows.Forms.Label();
            this.label_telc = new System.Windows.Forms.Label();
            this.button_canc = new System.Windows.Forms.Button();
            this.button_acep = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rBtnReto = new System.Windows.Forms.RadioButton();
            this.rBtnNormal = new System.Windows.Forms.RadioButton();
            this.label1 = new System.Windows.Forms.Label();
            this.pickerTime = new System.Windows.Forms.DateTimePicker();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // textBox_telc
            // 
            this.textBox_telc.Location = new System.Drawing.Point(218, 107);
            this.textBox_telc.Name = "textBox_telc";
            this.textBox_telc.Size = new System.Drawing.Size(100, 20);
            this.textBox_telc.TabIndex = 1;
            this.textBox_telc.TextChanged += new System.EventHandler(this.textBox_telc_TextChanged);
            // 
            // textBox_telref
            // 
            this.textBox_telref.Location = new System.Drawing.Point(218, 147);
            this.textBox_telref.Name = "textBox_telref";
            this.textBox_telref.Size = new System.Drawing.Size(100, 20);
            this.textBox_telref.TabIndex = 2;
            this.textBox_telref.TextChanged += new System.EventHandler(this.textBox_telref_TextChanged);
            // 
            // pickerDate
            // 
            this.pickerDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.pickerDate.Location = new System.Drawing.Point(218, 36);
            this.pickerDate.Name = "pickerDate";
            this.pickerDate.Size = new System.Drawing.Size(100, 20);
            this.pickerDate.TabIndex = 3;
            // 
            // label_fecha
            // 
            this.label_fecha.AutoSize = true;
            this.label_fecha.Location = new System.Drawing.Point(80, 36);
            this.label_fecha.Name = "label_fecha";
            this.label_fecha.Size = new System.Drawing.Size(40, 13);
            this.label_fecha.TabIndex = 4;
            this.label_fecha.Text = "Fecha:";
            // 
            // label_hora
            // 
            this.label_hora.AutoSize = true;
            this.label_hora.Location = new System.Drawing.Point(80, 73);
            this.label_hora.Name = "label_hora";
            this.label_hora.Size = new System.Drawing.Size(33, 13);
            this.label_hora.TabIndex = 5;
            this.label_hora.Text = "Hora:";
            // 
            // label_telref
            // 
            this.label_telref.AutoSize = true;
            this.label_telref.Location = new System.Drawing.Point(80, 150);
            this.label_telref.Name = "label_telref";
            this.label_telref.Size = new System.Drawing.Size(83, 13);
            this.label_telref.TabIndex = 6;
            this.label_telref.Text = "Tel. Referencia:";
            // 
            // label_telc
            // 
            this.label_telc.AutoSize = true;
            this.label_telc.Location = new System.Drawing.Point(80, 110);
            this.label_telc.Name = "label_telc";
            this.label_telc.Size = new System.Drawing.Size(63, 13);
            this.label_telc.TabIndex = 7;
            this.label_telc.Text = "Tel. Cliente:";
            // 
            // button_canc
            // 
            this.button_canc.BackColor = System.Drawing.SystemColors.Control;
            this.button_canc.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_canc.Location = new System.Drawing.Point(-7, 228);
            this.button_canc.Name = "button_canc";
            this.button_canc.Size = new System.Drawing.Size(219, 49);
            this.button_canc.TabIndex = 8;
            this.button_canc.Text = "Cancelar";
            this.button_canc.UseVisualStyleBackColor = false;
            this.button_canc.Click += new System.EventHandler(this.button_canc_Click);
            // 
            // button_acep
            // 
            this.button_acep.BackColor = System.Drawing.SystemColors.Control;
            this.button_acep.Enabled = false;
            this.button_acep.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_acep.Location = new System.Drawing.Point(208, 228);
            this.button_acep.Name = "button_acep";
            this.button_acep.Size = new System.Drawing.Size(218, 49);
            this.button_acep.TabIndex = 9;
            this.button_acep.Text = "Aceptar";
            this.button_acep.UseVisualStyleBackColor = false;
            this.button_acep.Click += new System.EventHandler(this.button_acep_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rBtnReto);
            this.groupBox1.Controls.Add(this.rBtnNormal);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.pickerTime);
            this.groupBox1.Controls.Add(this.label_fecha);
            this.groupBox1.Controls.Add(this.label_hora);
            this.groupBox1.Controls.Add(this.label_telc);
            this.groupBox1.Controls.Add(this.button_acep);
            this.groupBox1.Controls.Add(this.label_telref);
            this.groupBox1.Controls.Add(this.button_canc);
            this.groupBox1.Controls.Add(this.textBox_telref);
            this.groupBox1.Controls.Add(this.textBox_telc);
            this.groupBox1.Controls.Add(this.pickerDate);
            this.groupBox1.Location = new System.Drawing.Point(1, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(414, 277);
            this.groupBox1.TabIndex = 10;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Ingrese los datos";
            // 
            // rBtnReto
            // 
            this.rBtnReto.AutoSize = true;
            this.rBtnReto.Location = new System.Drawing.Point(282, 179);
            this.rBtnReto.Name = "rBtnReto";
            this.rBtnReto.Size = new System.Drawing.Size(48, 17);
            this.rBtnReto.TabIndex = 13;
            this.rBtnReto.TabStop = true;
            this.rBtnReto.Text = "Reto";
            this.rBtnReto.UseVisualStyleBackColor = true;
            this.rBtnReto.CheckedChanged += new System.EventHandler(this.rBtnReto_CheckedChanged);
            // 
            // rBtnNormal
            // 
            this.rBtnNormal.AutoSize = true;
            this.rBtnNormal.Location = new System.Drawing.Point(218, 179);
            this.rBtnNormal.Name = "rBtnNormal";
            this.rBtnNormal.Size = new System.Drawing.Size(58, 17);
            this.rBtnNormal.TabIndex = 12;
            this.rBtnNormal.TabStop = true;
            this.rBtnNormal.Text = "Normal";
            this.rBtnNormal.UseVisualStyleBackColor = true;
            this.rBtnNormal.CheckedChanged += new System.EventHandler(this.rBtnNormal_CheckedChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(80, 179);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(31, 13);
            this.label1.TabIndex = 11;
            this.label1.Text = "Tipo:";
            // 
            // pickerTime
            // 
            this.pickerTime.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            this.pickerTime.Location = new System.Drawing.Point(218, 73);
            this.pickerTime.Name = "pickerTime";
            this.pickerTime.Size = new System.Drawing.Size(100, 20);
            this.pickerTime.TabIndex = 10;
            // 
            // CrearReserv
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(414, 288);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "CrearReserv";
            this.Text = "Creacion de Reservacion";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.TextBox textBox_telc;
        private System.Windows.Forms.TextBox textBox_telref;
        private System.Windows.Forms.DateTimePicker pickerDate;
        private System.Windows.Forms.Label label_fecha;
        private System.Windows.Forms.Label label_hora;
        private System.Windows.Forms.Label label_telref;
        private System.Windows.Forms.Label label_telc;
        private System.Windows.Forms.Button button_canc;
        private System.Windows.Forms.Button button_acep;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.DateTimePicker pickerTime;
        private System.Windows.Forms.RadioButton rBtnReto;
        private System.Windows.Forms.RadioButton rBtnNormal;
        private System.Windows.Forms.Label label1;
    }
}