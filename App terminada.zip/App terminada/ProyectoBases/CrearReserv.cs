﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProyectoBases
{
    public partial class CrearReserv : Form
    {
        Reservacion reservacion;
        Encargado encargado;
        public CrearReserv()
        {
            InitializeComponent();
            reservacion = new Reservacion();
            encargado = new Encargado();
            this.CenterToScreen();
        }

        private void button_canc_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button_acep_Click(object sender, EventArgs e)
        {
            DateTime momento = pickerDate.Value.Date + pickerTime.Value.TimeOfDay;
            string telefonoReferencia = textBox_telref.Text;
            string cedula = encargado.getCedula();
            string telefonoCliente = textBox_telc.Text;
            if (rBtnNormal.Checked)
            {
                int resultado = reservacion.insertar_DeEquipoCompleto(momento, telefonoReferencia, cedula, false, telefonoCliente);
                if ( resultado == 245)
                {
                    MessageBox.Show("Algun error ha ocurrido, verifique los datos.", "Error nueva reservacion");
                }
            }
            else if (rBtnReto.Checked)
            {
                int resultado = reservacion.insertar_Reto(momento, telefonoReferencia, cedula, telefonoCliente);
                if (resultado == 245)
                {
                    MessageBox.Show("Algun error ha ocurrido, verifique los datos.", "Error nueva reservacion");
                }
            }

            this.Close();
        }

        private void textBox_telc_TextChanged(object sender, EventArgs e)
        {
            if (textBox_telc.Text != "" && (rBtnNormal.Checked || rBtnReto.Checked))
            {
                button_acep.Enabled = true;
            }
            else
            {
                button_acep.Enabled = false;
            }
        }

        private void textBox_telref_TextChanged(object sender, EventArgs e)
        {
            if (textBox_telc.Text != "" && (rBtnNormal.Checked || rBtnReto.Checked))
            {
                button_acep.Enabled = true;
            }
            else
            {
                button_acep.Enabled = false;
            }
        }

        private void rBtnNormal_CheckedChanged(object sender, EventArgs e)
        {
            if (textBox_telc.Text != "" && (rBtnNormal.Checked || rBtnReto.Checked))
            {
                button_acep.Enabled = true;
            }
            else
            {
                button_acep.Enabled = false;
            }
        }

        private void rBtnReto_CheckedChanged(object sender, EventArgs e)
        {
            if (textBox_telc.Text != "" && (rBtnNormal.Checked || rBtnReto.Checked))
            {
                button_acep.Enabled = true;
            }
            else
            {
                button_acep.Enabled = false;
            }
        }
    }
}
